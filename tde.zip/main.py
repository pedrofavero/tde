def uniao(conjunto1, conjunto2):
  return conjunto1.union(conjunto2) #faz a uniao, usando union do python

def intersecao(conjunto1, conjunto2):
  return conjunto1.intersection(conjunto2) #intesecao usando intercection

def diferenca(conjunto1, conjunto2):
  return conjunto1.difference(conjunto2) #usa difference 

def produto_cartesiano(conjunto1, conjunto2):
  return {(x, y) for x in conjunto1 for y in conjunto2} #faz um nested for loop e printa

def operacoes(arquivo):
  with open(arquivo) as arquivo:
      num_operacoes = int(arquivo.readline().strip()) #para ler o arquivo
      resultados = []

      for _ in range(num_operacoes):
          codigo_operacao = arquivo.readline().strip() #peguei do StackOverflow
          conjunto1 = set(map(str.strip, arquivo.readline().split(',')))
          conjunto2 = set(map(str.strip, arquivo.readline().split(',')))

          if codigo_operacao == 'U':
              resultado = uniao(conjunto1, conjunto2) #chama a funcao uniao
              nome_operacao = 'União'
          elif codigo_operacao == 'I':
              resultado = intersecao(conjunto1, conjunto2) #chama a funcao intersecao
              nome_operacao = 'Interseção'
          elif codigo_operacao == 'D':
              resultado = diferenca(conjunto1, conjunto2) #chama a funcao diferenca
              nome_operacao = 'Diferença'
          elif codigo_operacao == 'C':
              resultado = produto_cartesiano(conjunto1, conjunto2) #chama a funcao 
              nome_operacao = 'Produto Cartesiano'

          resultados.append(f"{nome_operacao}: conjunto 1 {{{', '.join(conjunto1)}}}, conjunto 2 {{{', '.join(conjunto2)}}}.                 Resultado: {{{', '.join(map(str, resultado))}}}")

      for resultado in resultados:
          print(resultado)

arquivo = 'teste2.txt'  # Substitua pelo caminho do arquivo de texto
operacoes(arquivo)
